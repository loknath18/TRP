import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Components
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { HomeComponent } from './components/home/home.component';
import { AddProfileComponent } from './components/add-profile/add-profile.component';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { UploadResumeComponent } from './components/upload-resume/upload-resume.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { ForgotUseridComponent } from './components/forgot-userid/forgot-userid.component';
import { HelpComponent } from './components/help/help.component';

import { AuthGuard } from './guards/auth-guard';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegistrationComponent },
  // { path: 'forgot-password', component: ForgotPasswordComponent, canActivate: [AuthGuard] },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'forgot-userid', component: ForgotUseridComponent },
  { path: 'home', component: HomeComponent },
  { path: 'add-profile', component: AddProfileComponent },
  { path: 'update-profile', component: UpdateProfileComponent },
  { path: 'upload-resume', component: UploadResumeComponent },
  { path: 'help', component: HelpComponent },

  // otherwise redirect to home
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
