import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';

// Modules
import { AppRoutingModule } from './app-routing.module';
import { CoreModule } from './core/core.module';

// Components
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { HomeComponent } from './components/home/home.component';
import { PageLoaderComponent } from './shared/components/page-loader/page-loader.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { HelpComponent } from './components/help/help.component';
import { AddProfileComponent } from './components/add-profile/add-profile.component';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { UploadResumeComponent } from './components/upload-resume/upload-resume.component';
import { ForgotUseridComponent } from './components/forgot-userid/forgot-userid.component';

// Services
import { AuthGuard } from './guards/auth-guard';
import { APIService } from './shared/web-services/api.service';
import { HttpService } from './shared//web-services/http.service';
import { PageLoaderService } from './shared/services/page-loader.service';
import { SessionService } from './shared/services/session.service';

// PrimeNg modules
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { TableModule } from 'primeng/table';
import { TabMenuModule } from 'primeng/tabmenu';
import { FileUploadModule } from 'primeng/fileupload';
import { DynamicDialogModule } from 'primeng/dynamicdialog';

// Pipes
import { KeysPipe } from './shared/pipes/keys-pipe';
import { ViewResumeDetailsComponent } from './components/view-resume-details/view-resume-details.component';

@NgModule({
  declarations: [
    AddProfileComponent,
    AppComponent,
    ForgotPasswordComponent,
    HelpComponent,
    HomeComponent,
    LoginComponent,
    PageLoaderComponent,
    RegistrationComponent,
    UpdateProfileComponent,
    UploadResumeComponent,
    ForgotUseridComponent,
    KeysPipe,
    ViewResumeDetailsComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserAnimationsModule,
    BrowserModule,
    CoreModule,
    FormsModule,
    FileUploadModule,
    HttpClientModule,
    MessageModule,
    MessagesModule,
    TableModule,
    TabMenuModule,
    DynamicDialogModule
  ],
  providers: [APIService, AuthGuard, HttpService, PageLoaderService, SessionService],
  bootstrap: [AppComponent],
  entryComponents: [
    ViewResumeDetailsComponent
]
})
export class AppModule { }
