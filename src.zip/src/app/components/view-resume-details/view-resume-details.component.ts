import { Component, OnInit } from '@angular/core';
import { APIService } from '../../shared/web-services/api.service';
import { SessionService } from '../../shared/services/session.service';

import {DynamicDialogConfig} from 'primeng/api';
import {DynamicDialogRef} from 'primeng/api';

@Component({
  selector: 'app-view-resume-details',
  templateUrl: './view-resume-details.component.html',
  styleUrls: ['./view-resume-details.component.css']
})
export class ViewResumeDetailsComponent implements OnInit {

  selectedResumeDetails: any = {};
  loading: boolean;
  msgs: any[];
  resourceId: any;

  constructor(private apiService: APIService,
    private sessionService: SessionService,
    public config: DynamicDialogConfig,
    public ref: DynamicDialogRef) { }

  ngOnInit() {
    console.log("in ViewResumeDetailsComponent");
    this.msgs = [];
    this.resourceId = this.config.data.id;
    this.getResourceDetails(this.resourceId);
    console.log(this.resourceId);
  }

  getResourceDetails(resourceId: any) {
    this.apiService.getResourceDetails(resourceId).subscribe(
      data => {
        this.selectedResumeDetails = data;
        console.log(this.selectedResumeDetails);
      }, error => {
        this.msgs.push({ severity: 'error', summary: 'Unable to fetch resume details', detail: '' });
        this.sessionService.showMessages(this.msgs);
      });
  }

}
