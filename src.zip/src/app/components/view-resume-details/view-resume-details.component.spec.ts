import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewResumeDetailsComponent } from './view-resume-details.component';

describe('ViewResumeDetailsComponent', () => {
  let component: ViewResumeDetailsComponent;
  let fixture: ComponentFixture<ViewResumeDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewResumeDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewResumeDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
