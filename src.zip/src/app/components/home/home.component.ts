import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { APIService } from '../../shared/web-services/api.service';
import { SessionService } from '../../shared/services/session.service';
import { MenuItem } from 'primeng/api';

import * as FileSaver from 'file-saver';
import * as _ from 'underscore';

import { DialogService } from 'primeng/api';

import { ViewResumeDetailsComponent } from '../view-resume-details/view-resume-details.component';

export interface Resume {
  resourceId?;
  createdTs?;
  firstName?;
  lastName?;
  primaryPhone?;
  role?;
  workAuthId?;
  status?;
  resume?;
  details?;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [DialogService]
})
export class HomeComponent implements OnInit {

  cols: any[];
  msgs: any[];
  resumeDetails: any[];
  selectedResumes: Resume[];
  selectedRow: any;
  totalRecordsCount: number;
  newResourceDetails: any[];
  inProgressResourceDetails: any[];
  completedResourceDetails: any[];
  totalNewRecords: number;
  totalInProgressRecords: number;
  totalCompletedRecords: number;
  menuTabs: MenuItem[];
  activeItem: any;
  pageHeight: number;
  loading: boolean;
  downloadResumeDetails: any;


  constructor(private apiService: APIService,
    private router: Router,
    private sessionService: SessionService,
    public dialogService: DialogService) {
  }

  ngOnInit() {

    this.pageHeight = 700;

    this.selectedResumes = [];

    this.menuTabs = [
      { label: 'New Resume', icon: 'fa fa-fw fa-bar-chart' },
      { label: 'Work In Progress', icon: 'fa fa-fw fa-calendar' },
      { label: 'Old Resume', icon: 'fa fa-fw fa-book' }
    ];
    this.activeItem = this.menuTabs[0];

    this.cols = [
      { field: 'resourceId', header: 'ID' },
      { field: 'createdTs', header: 'Date & Time' },
      { field: 'firstName', header: 'Name' },
      { field: 'lastName', header: 'LastName' },
      { field: 'primaryPhone', header: 'Phone' },
      { field: 'desiredPosition', header: 'Role' },
      { field: 'workAuthId', header: 'Visa' },
      { field: 'status', header: 'Status' },
      { field: 'resume', header: 'Download Resume' }
      // { field: 'details', header: 'View Resume' }
    ];

    this.getResumeDetails();
  }

  isPaginatorVisible() {
    return this.resumeDetails && this.resumeDetails.length > 0;
  }

  getResumeDetails() {
    this.apiService.getResumeDetails().subscribe(
      data => {
        if (data && data.responseCode && data.responseCode.errorMsg === 'SUCCESS') {
          this.newResourceDetails = data.newResourceDetailDTO && data.newResourceDetailDTO.newResourceDetailList ? data.newResourceDetailDTO.newResourceDetailList : [];
          this.totalNewRecords = data.newResourceDetailDTO && data.newResourceDetailDTO.totalRecords ? data.newResourceDetailDTO.totalRecords : 0;
          this.resumeDetails = this.newResourceDetails;
          this.totalRecordsCount = this.totalNewRecords;

          this.inProgressResourceDetails = data.wipResourceDetailDTO && data.wipResourceDetailDTO.wipResourceDetailList ? data.wipResourceDetailDTO.wipResourceDetailList : [];
          this.totalInProgressRecords = data.wipResourceDetailDTO && data.wipResourceDetailDTO.totalRecords ? data.wipResourceDetailDTO.totalRecords : 0;

          this.completedResourceDetails = data.compResourceDetailDTO && data.compResourceDetailDTO.compResourceDetailList ? data.compResourceDetailDTO.compResourceDetailList : [];
          this.totalCompletedRecords = data.compResourceDetailDTO && data.compResourceDetailDTO.totalRecords ? data.compResourceDetailDTO.totalRecords : 0;
        }
      },
      error => {
        this.msgs.push({ severity: 'error', summary: 'Something went wrong, please try again later', detail: '' });
        this.sessionService.showMessages(this.msgs);
      });
  }

  addProfile() {
    this.router.navigate(['add-profile']);
  }

  updateProfile() {
    console.log(this.selectedResumes[0]);
    this.msgs = [];
    if (this.selectedResumes && this.selectedResumes.length == 0) {
      this.msgs.push({ severity: 'error', summary: 'Select at least one record to update', detail: '' });
    } else if (this.selectedResumes && this.selectedResumes.length > 1) {
      this.msgs.push({ severity: 'error', summary: 'More than one record cannot be updated', detail: '' });
    } else if (this.selectedResumes && this.selectedResumes.length > 0) {
      this.sessionService.setSelectedResume(this.selectedResumes[0]);
      this.router.navigate(['/update-profile'], { queryParams: { resourceId: this.selectedResumes[0].resourceId } });
    }
  }

  onTableHeaderCheckboxToggle(event: any) {
    console.log(event);
  }

  onClickBtn(type: string) {
    if (type == 'New Resume') {
      this.resumeDetails = this.newResourceDetails;
      this.totalRecordsCount = this.totalNewRecords;
    } else if (type == 'Work In Progress') {
      this.resumeDetails = this.inProgressResourceDetails;
      this.totalRecordsCount = this.totalInProgressRecords;
    }
    else {
      this.resumeDetails = this.completedResourceDetails;
      this.totalRecordsCount = this.totalCompletedRecords;
    }
  }

  uploadResume() {
    console.log("upload resume");
    this.router.navigate(['/upload-resume']);
  }

  setHeightOnRowPerPageSelect(event?: any) {
    if (event.rows == 20) {
      window.scrollTo(0, 0);
      this.pageHeight = window.outerHeight + 500;
    } else {
      window.scrollTo(0, 0);
      this.pageHeight = window.innerHeight + 220;
    }

  }

  downloadResume(resumeId: any) {
    this.loading = false;
    this.msgs = [];
    this.apiService.downloadResumeById(resumeId).subscribe(
      data => {
        this.loading = false;
        this.downloadResumeDetails = data;
        if (this.downloadResumeDetails.resumeDoc) {
          // let blob = this.converBase64toBlob(this.downloadResumeDetails.resumeDoc, 'application/msword');
          var blob = new Blob([this.downloadResumeDetails.resumeDoc, 'application/msword']);
          FileSaver.saveAs(blob, (this.downloadResumeDetails.resumeId) + ".doc");
          // var blobURL = URL.createObjectURL(blob);
          // window.open(blobURL);
        }
      },
      error => {
        this.msgs.push({ severity: 'error', summary: 'Unable fetch resume details', detail: '' });
        this.sessionService.showMessages(this.msgs);
        this.loading = false;
      });
  }

  converBase64toBlob(content: any, contentType: string) {
    contentType = contentType || '';
    var sliceSize = 512;
    var byteCharacters = window.atob(content); //method which converts base64 to binary
    var byteArrays = [
    ];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);
      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    var blob = new Blob(content, {
      type: contentType
    }); //statement which creates the blob
    return blob;
  }

  //   public base64ToBlob(b64Data, contentType='', sliceSize=512) {
  //     b64Data = b64Data.replace(/\s/g, ''); //IE compatibility...
  //     let byteCharacters = atob(b64Data);
  //     let byteArrays = [];
  //     for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
  //         let slice = byteCharacters.slice(offset, offset + sliceSize);

  //         let byteNumbers = new Array(slice.length);
  //         for (var i = 0; i < slice.length; i++) {
  //             byteNumbers[i] = slice.charCodeAt(i);
  //         }
  //         let byteArray = new Uint8Array(byteNumbers);
  //         byteArrays.push(byteArray);
  //     }
  //     return new Blob(byteArrays, {type: contentType});
  // }


  viewResumeDetails(resourceId: any) {
    const ref = this.dialogService.open(ViewResumeDetailsComponent, {
      data: {
        id: resourceId
      },
      header: 'View Resume Details',
      width: '70%'
    });
  }

}
