import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import * as _ from 'underscore';

import { APIService } from '../../shared/web-services/api.service';
import { SessionService } from '../../shared/services/session.service';

export interface skills {
  skillType: string;
}

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  selectedResume: any = {};
  states: any[];
  cities: any[];
  resourceId: any;
  msgs: any[];
  model: any = {};
  resumeStatuses: string[];
  loading: boolean;
  selectedStatus: any;
  fileName: string;
  fileSize: string;
  uploadedFile: any;
  skills: any[] = [];
  selectedSkills: skills[];
  isSkillsExceeded: boolean;
  isAddBtnDisplay: boolean;

  constructor(private location: Location,
    private route: ActivatedRoute,
    private apiService: APIService,
    private sessionService: SessionService) { }

  ngOnInit() {
    this.selectedResume.status = '';
    this.msgs = [];
    this.selectedResume.state = '';
    this.route.queryParams.subscribe(params => {
      this.resourceId = +params['resourceId'] || 0;
    });
    console.log("Selected Resume Details: " + this.resourceId);
    this.getResourceDetails(this.resourceId);
    this.getResumeStatuses();
    this.getStatesByCountryName("US");
  }

  getResourceDetails(resourceId: any) {
    this.apiService.getResourceDetails(resourceId).subscribe(
      data => {
        this.selectedResume = data;
        console.log(this.selectedResume.status);
      }, error => {
        this.msgs.push({ severity: 'error', summary: 'Unable to fetch resource details', detail: '' });
      });
  }

  getStatesByCountryName(countryName: string) {
    this.loading = false;
    this.msgs = [];
    this.apiService.getStatesById(countryName).subscribe(
      data => {
        this.loading = false;
        this.states = data;
        console.log(this.states);
      },
      error => {
        this.msgs.push({ severity: 'error', summary: 'Unable fetch states', detail: '' });
        this.sessionService.showMessages(this.msgs);
        this.loading = false;
      });
  }

  getResumeStatuses() {
    this.loading = false;
    this.msgs = [];
    this.apiService.getResumeStatuses().subscribe(
      data => {
        this.loading = false;
        this.resumeStatuses = data;
        console.log(this.resumeStatuses);
      },
      error => {
        this.msgs.push({ severity: 'error', summary: 'Unable fetch statuses', detail: '' });
        this.sessionService.showMessages(this.msgs);
        this.loading = false;
      });
  }

  goBack() {
    this.location.back();
  }

  updateProfile() {
    this.apiService.updateProfile(this.selectedResume).subscribe(
      data => {
        this.msgs.push({ severity: 'success', summary: 'Profile updated successfully', detail: '' });
        window.scrollTo(0, 0);
      }, error => {
        this.msgs.push({ severity: 'error', summary: 'Something went wrong', detail: 'Failed to update profile' });
      });

  }

  // upload file and encode it to base 64 format
  handleFileInput(files: FileList) {
    
        if (files.length > 0) {
    
          let file: File = files[0];
          let fileFormat = file.name.split('.').pop();
          this.fileSize = (file.size / (1024 * 1024)).toFixed(2);
    
          if (parseInt(this.fileSize) > 1) {
            this.msgs.push({ severity: 'error', summary: 'File size exceeds', detail: '' });
            this.sessionService.showMessages(this.msgs);
            window.scrollTo(0, 0);
          } else if (_.contains(["doc", "docx"], fileFormat)) {
    
            this.fileName = file.name;
            let myReader: FileReader = new FileReader();
            this.uploadedFile = file;
    
            myReader.onloadend = (e) => {
              this.uploadedFile = myReader.result;
            }
            myReader.readAsDataURL(file);
            console.log(this.uploadedFile);
    
          } else {
            this.msgs.push({ severity: 'error', summary: 'Invalid file format', detail: '' });
            this.sessionService.showMessages(this.msgs);
            window.scrollTo(0, 0);
          }
    
        }
    
      }
    
      addSkills() {
        this.skills.push({});
        this.selectedSkills.push({skillType: ''});
        this.skills && this.skills.length > 0 ? this.isAddBtnDisplay = false : this.isAddBtnDisplay = true;
    
        // if(this.skills && this.skills.length >3) {
        //   this.isSkillsExceeded = true;
        // } else {
        //   this.isSkillsExceeded = false;
        //   this.skills.push(req);
        // }
      }
    
      deleteSkills(index: number) {
        this.skills.splice(index, 1);
        this.selectedSkills.splice(index, 1);
        this.skills && this.skills.length == 0 ? this.isAddBtnDisplay = true : this.isAddBtnDisplay = false;
      }

}
