import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { APIService } from '../../shared/web-services/api.service';
import { SessionService } from '../../shared/services/session.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  model: any = {};
  loading = false;
  msgs: any[];
  isUserExists:any;

  constructor(private router: Router,
    private apiService: APIService,
    private sessionService: SessionService) { }

  ngOnInit() {
    this.model.securityQuestion = '';
    this.isUserExists = '';
  }

  register() {
    this.loading = true;
    this.msgs = [];
    console.log(this.model);

    this.apiService.regsiterUser(this.model).subscribe(
      data => {
        this.msgs.push({ severity: 'success', summary: 'Registartion successful', detail: '' });
        this.sessionService.showMessages(this.msgs);
        this.router.navigate(['login']);
      },
      error => {
        this.msgs.push({ severity: 'error', summary: 'Something went grwong', detail: 'Registartion un-successful' });
        this.sessionService.showMessages(this.msgs);
        this.loading = false;
      });
  }

  validateUserId(event: any) {
    
    this.apiService.validateUserId(event.target.value).subscribe(
      data => {
        this.isUserExists = data.isUserExists ? 'N': 'Y';
      },
      error => {
        this.msgs.push({ severity: 'error', summary: 'Something went grwong', detail: 'Unable to validate user id' });
        this.loading = false;
      });
  }

}
