import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

import { SessionService } from '../../shared/services/session.service';

@Component({
  selector: 'app-upload-resume',
  templateUrl: './upload-resume.component.html',
  styleUrls: ['./upload-resume.component.css']
})
export class UploadResumeComponent implements OnInit {

  uploadedFiles: any[] = [];
  msgs: any[];
  url: string;

  constructor(private location: Location,
    private sessionService: SessionService) { }

  ngOnInit() {
    console.log("on init");
    // this.url = "http://172.16.75.99:8443/trp/uploadResume";
    this.url = "http://172.16.75.112:8080/trp/uploadResume";

  }

  goBack() {
    this.location.back();
  }

  onUpload(event: any) {
    console.log("onUpload");
    for (let file of event.files) {
      this.uploadedFiles.push(file);
    }
    this.msgs = [];
    this.msgs.push({ severity: 'success', summary: 'File(s) uploaded successfully', detail: '' });
    this.sessionService.showMessages(this.msgs);
    window.scrollTo(0, 0);
  }

  onErrorFileUpload(event: any) {
    console.log(event);
    this.msgs = [];
    this.msgs.push({ severity: 'error', summary: 'File upload failed, please try again', detail: '' });
    this.sessionService.showMessages(this.msgs);
    window.scrollTo(0, 0);
  }
}
