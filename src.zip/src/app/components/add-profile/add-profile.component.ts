import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import * as _ from 'underscore';

import { APIService } from '../../shared/web-services/api.service';
import { SessionService } from '../../shared/services/session.service';

export interface skills {
  skillType: string;
}

@Component({
  selector: 'app-add-profile',
  templateUrl: './add-profile.component.html',
  styleUrls: ['./add-profile.component.css']
})
export class AddProfileComponent implements OnInit {

  selectedResume: any = {};
  msgs: any[];
  loading: boolean;
  fileName: string;
  fileSize: string;
  uploadedFile: any;
  states: string[];
  resumeStatuses: string[];
  skills: any[] = [];
  selectedSkills: any[];
  isSkillsExceeded: boolean;
  isAddBtnDisplay: boolean;

  constructor(private apiService: APIService,
    private sessionService: SessionService,
    private router: Router,
    private location: Location) { }

  ngOnInit() {
    this.msgs = [];
    this.isSkillsExceeded = false;
    this.isAddBtnDisplay = false;
    this.skills.push({});
    this.selectedSkills = [
      {
        skillType: ''
      }
    ];
    this.selectedResume.status = '';
    this.selectedResume.state = '';
    this.getStatesByCountryName("US");
    this.getResumeStatuses();
    console.log("in ngOnInit()");
  }

  getStatesByCountryName(countryName: string) {
    this.loading = false;
    this.msgs = [];
    this.apiService.getStatesById(countryName).subscribe(
      data => {
        this.loading = false;
        this.states = data;
        console.log(this.states);
      },
      error => {
        this.msgs.push({ severity: 'error', summary: 'Unable fetch states', detail: '' });
        this.sessionService.showMessages(this.msgs);
        this.loading = false;
      });
  }

  getResumeStatuses() {
    this.loading = false;
    this.msgs = [];
    this.apiService.getResumeStatuses().subscribe(
      data => {
        this.loading = false;
        this.resumeStatuses = data;
        console.log(this.resumeStatuses);
      },
      error => {
        this.msgs.push({ severity: 'error', summary: 'Unable fetch statuses', detail: '' });
        this.sessionService.showMessages(this.msgs);
        this.loading = false;
      });
  }

  addProfile() {
    this.loading = false;
    this.msgs = [];
    this.selectedResume.resumeDoc = this.uploadedFile;
    this.prepareSKills(this.selectedSkills);
    console.log(this.selectedResume);
    this.apiService.addProfile(this.selectedResume).subscribe(
      data => {
        this.loading = false;
        this.msgs.push({ severity: 'success', summary: 'Profile added successfully', detail: '' });
        this.sessionService.showMessages(this.msgs);
        window.scrollTo(0, 0);
        this.selectedResume == {};
        this.router.navigate(['home']);

      },
      error => {
        this.msgs.push({ severity: 'error', summary: 'Unable save profile', detail: 'Something went wrong, please try again later' });
        this.sessionService.showMessages(this.msgs);
        this.loading = false;
      });
  }

  prepareSKills(selectedSkills: any[]) {
    console.log(selectedSkills);
  }

  goBack() {
    this.location.back();
  }

  // upload file and encode it to base 64 format
  handleFileInput(files: FileList) {

    if (files.length > 0) {

      let file: File = files[0];
      let fileFormat = file.name.split('.').pop();
      this.fileSize = (file.size / (1024 * 1024)).toFixed(2);

      if (parseInt(this.fileSize) > 1) {
        this.msgs.push({ severity: 'error', summary: 'File size exceeds', detail: '' });
        this.sessionService.showMessages(this.msgs);
        window.scrollTo(0, 0);
      } else if (_.contains(["doc", "docx"], fileFormat)) {

        this.fileName = file.name;
        let myReader: FileReader = new FileReader();
        this.uploadedFile = file;

        myReader.onloadend = (e) => {
          this.uploadedFile = myReader.result;
        }
        myReader.readAsDataURL(file);
        console.log(this.uploadedFile);

      } else {
        this.msgs.push({ severity: 'error', summary: 'Invalid file format', detail: '' });
        this.sessionService.showMessages(this.msgs);
        window.scrollTo(0, 0);
      }

    }

  }

  addSkills() {
    this.skills.push({});
    this.selectedSkills.push({});
    this.skills && this.skills.length > 0 ? this.isAddBtnDisplay = false : this.isAddBtnDisplay = true;
    console.log(this.selectedSkills);

    // if(this.skills && this.skills.length >3) {
    //   this.isSkillsExceeded = true;
    // } else {
    //   this.isSkillsExceeded = false;
    //   this.skills.push(req);
    // }
  }

  deleteSkills(index: number) {
    this.skills.splice(index, 1);
    this.selectedSkills.splice(index, 1);
    this.skills && this.skills.length == 0 ? this.isAddBtnDisplay = true : this.isAddBtnDisplay = false;
  }

}
