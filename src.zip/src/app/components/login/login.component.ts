import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { PageLoaderService } from '../../shared/services/page-loader.service';
import { APIService } from '../../shared/web-services/api.service';
import { SessionService } from '../../shared/services/session.service';

@Component({
    templateUrl: 'login.component.html'
})

export class LoginComponent implements OnInit {
    model: any = {};
    loading = false;
    returnUrl: string;
    msgs: any[];

    constructor(
        private route: ActivatedRoute,
        private pageLoaderService: PageLoaderService,
        private router: Router,
        private apiService: APIService,
        private sessionService: SessionService) { }

    ngOnInit() {
    }

    login() {
        this.loading = true;
        this.pageLoaderService.show();
        this.msgs = [];
        console.log(this.model);
        this.apiService.login(this.model).subscribe(
            data => {
                //this.sessionService.setLoggedInUser(data.firstName + data.lastName);
                this.pageLoaderService.hide();
                this.sessionService.setLoggedInUser(data.userId);
                this.sessionService.setIsUserLoggedIn('Y');
                this.router.navigate(['/home']);
                this.loading = false;
            },
            error => {
                this.pageLoaderService.hide();
                this.msgs.push({ severity: 'error', summary: 'Invalid credentials, please try again', detail: '' });
                this.sessionService.showMessages(this.msgs);
                this.loading = false;
            });
    }
}
