import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import {
    getResumesURL,
    getResourceDetailsURL,
    registerUserURL,
    loginURL,
    addProfileURL,
    updateProfileURL,
    getStatesByIdURL,
    isUserExistsURL,
    forgotPasswordURL,
    forgotUserIdURL,
    getStatusURL,
    getDownloadResumeURL
} from '../constants/web-constants';
import { HttpService } from './http.service';


@Injectable()
export class APIService extends HttpService {

    constructor(private http: HttpClient) {
        super();
    }

    regsiterUser(req: any) {
        return this.http.post(registerUserURL, req, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    login(req: any) {
        return this.http.post(loginURL, req, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    getResumeDetails() {
        // return this.http.post(getResumesURL, {}, {
        return this.http.get(getResumesURL, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    addProfile(req: any) {
        return this.http.post(addProfileURL, req, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    updateProfile(req: any) {
        return this.http.post(updateProfileURL, req, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    getResourceDetails(resourceId: any) {
        // return this.http.get(getResourceDetailsURL + '/' + resourceId, {
        return this.http.get(getResourceDetailsURL, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    getStatesById(counrtyName: string) {
        // return this.http.get(getStatesByIdURL + "/" + counrtyName, {
        return this.http.get(getStatesByIdURL, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    validateUserId(userId: string) {
        return this.http.get(isUserExistsURL + "/" + userId, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    forgotPassword(req: any) {
        return this.http.post(forgotPasswordURL, req, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    forgotUserId(req: any) {
        return this.http.post(forgotUserIdURL, req, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    getResumeStatuses() {
        return this.http.get(getStatusURL, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

    downloadResumeById(resourceId: any) {
        return this.http.get(getDownloadResumeURL + "/" + resourceId, {
            observe: 'response',
        }).pipe(
            map(this.extractData),
            catchError(this.handleError));
    }

}