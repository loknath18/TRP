import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Title } from '@angular/platform-browser';
import { throwError as observableThrowError, Observable } from 'rxjs';

import { environment } from '../../../environments/environment';

@Injectable()
export class HttpService {

    constructor() {}

    addRequestHttpHeader() {

        let headerJson = {
            'Content-type': 'appilication/json'
        }

        return new HttpHeaders(headerJson);
    }

    handleError = (error: HttpErrorResponse | any) => {

        let errMsg: string;

        errMsg = error.message ? error.message : error.toString();

        // TODO: log error message
        return observableThrowError(errMsg);

    }

    extractData = (res: Response | any) => {

        return res.body || {};

    }

    handleResponse<T>(res: HttpResponse<T> | any): T {

        let body = (res && res.body) ? res.body : null;
        return body;

    }

}
