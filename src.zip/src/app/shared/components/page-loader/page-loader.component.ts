import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';

import { PageLoaderState, PageLoaderService } from '../../services/page-loader.service';

@Component({
  selector: 'pos-page-loader',
  templateUrl: './page-loader.component.html'
})
export class PageLoaderComponent implements OnDestroy, OnInit {

  visible = false;
  private pageLoaderStateChanged: Subscription;

  constructor(
    private pageLoaderService: PageLoaderService
  ) {}

  ngOnInit() {
    let body = document.getElementsByTagName('body')[0];

    this.pageLoaderStateChanged = this.pageLoaderService.loaderState
      .subscribe((state: PageLoaderState) => {
        this.visible = state.show;
        (this.visible) ? body.classList.add('page-loader-open') : body.classList.remove('page-loader-open');
      });
  }

  ngOnDestroy() {
    this.pageLoaderStateChanged.unsubscribe();
  }

}
