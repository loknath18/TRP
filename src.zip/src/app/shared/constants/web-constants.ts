import { environment } from '../../../environments/environment';

// Local Dummy JSON URL's
export const http_url = "http://localhost:3000/"; 

//tc server
// export const http_url = "http://172.16.75.99:8443/trp/";

// Actual Hostname
// export const http_url = "http://172.16.75.112:8080/trp/";
export const loginURL = http_url + "login";
export const registerUserURL = http_url + "register";
export const isUserExistsURL = http_url + "isUserExists";
export const getResumesURL = http_url + "searchResource";
export const addProfileURL = http_url + "saveResource";
export const updateProfileURL = http_url + "saveResource";
export const getResourceDetailsURL = http_url + "getResourceById";
export const forgotPasswordURL = http_url + "forgotPwd";
export const forgotUserIdURL = http_url + "forgotUserId";
export const getStatusURL = http_url + "getStatus";
export const getStatesByIdURL = http_url + "getStatesById";
export const getDownloadResumeURL = http_url + "getResumeById";





