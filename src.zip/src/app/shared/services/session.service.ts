import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class SessionService {

    selectedResume: any = {};
    loggedInUserSubject = new Subject<string>();
    loggedInUserObservable: Observable<string>;
    isUserLoggedInSubject = new Subject<string>();
    isUserLoggedInObservable: Observable<string>;
    messagesSubject = new Subject<any[]>();
    messagesObservable: Observable<any[]>;

    constructor() {
        this.loggedInUserObservable = this.loggedInUserSubject.asObservable();
        this.isUserLoggedInObservable = this.isUserLoggedInSubject.asObservable();
        this.messagesObservable = this.messagesSubject.asObservable();
    }

    setSelectedResume(selectedResume: any) {
        this.selectedResume = selectedResume;
    }

    getSelectedResume() {
        return this.selectedResume;
    }

    setLoggedInUser(userName: string) {
        this.loggedInUserSubject.next(userName);
    }

    setIsUserLoggedIn(isUserLoggedIn: string) {
        this.isUserLoggedInSubject.next(isUserLoggedIn);
    }

    showMessages(messages: any[]) {
        this.messagesSubject.next(messages);
    }

}