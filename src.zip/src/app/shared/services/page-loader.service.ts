import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface PageLoaderState {
  show: boolean;
}

@Injectable()
export class PageLoaderService {

  loaderState;

  private loaderSubject = new Subject<PageLoaderState>();

  constructor() {
    this.loaderState = this.loaderSubject.asObservable();
  }

  show() {
    this.loaderSubject.next(<PageLoaderState>{ show: true });
  }

  hide() {
    this.loaderSubject.next(<PageLoaderState>{ show: false });
  }

}
