import { Component, OnInit } from '@angular/core';
import { Observable, Subject, Subscription } from 'rxjs';
import { Router } from '@angular/router';

import { SessionService } from '../../shared/services/session.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  userName: string;
  loggedInUser: string;
  isAlreadyLoggedIn: string;
  isUserLoggedIn: string;
  currentPage: string;

  constructor(private sessionService: SessionService,
    private router: Router,) { }

  ngOnInit() {
    this.currentPage = this.router.url;
    this.sessionService.loggedInUserObservable.subscribe(
      data => {
        this.userName = data;
        localStorage.setItem('userName', data);
        console.log("Logged In User: ", this.userName);
      }
    );

    this.sessionService.isUserLoggedInObservable.subscribe(
      data => {
        this.isAlreadyLoggedIn = data;
        localStorage.setItem('isUserLoggedIn', this.isAlreadyLoggedIn);
        console.log("Is User Logged In: ", this.isAlreadyLoggedIn);
      }
    );

    this.loggedInUser = this.userName ? this.userName: localStorage.getItem('userName') ? localStorage.getItem('userName'): 'Guest';    
    this.isUserLoggedIn = this.isAlreadyLoggedIn ? this.isAlreadyLoggedIn: localStorage.getItem('isUserLoggedIn');   
  }

  logout() {
    localStorage.removeItem('userName');
    this.router.navigate(['/', 'login']);
  }

}
